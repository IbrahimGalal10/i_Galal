// Example of a basic validation for the form
document.getElementById('addMemberForm').addEventListener('submit', function(event) {
    const phoneNumber = document.getElementById('phone_number').value;
    
    // Check if phone number is a valid 10-digit number
    if (isNaN(phoneNumber) || phoneNumber.length !== 10) {
        alert("Please enter a valid 10-digit phone number.");
        event.preventDefault();  // Prevent form submission
    }
});